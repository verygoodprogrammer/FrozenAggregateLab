package freezingAggregation;

import sim.engine.SimState;
import sim.engine.Steppable;

public class Agent implements Steppable {

	@Override
	public void step(SimState state) {
		// TODO Auto-generated method stub

	}

}
