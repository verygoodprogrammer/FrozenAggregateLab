package freezingAggregation;

import sim.engine.SimState;

public class Environment extends SimState {

	public Environment(long seed) {
		super(seed);
		// TODO Auto-generated constructor stub
	}
	
	public void start() {
		super.start();
		//my code
		
	}

}
